<?php

use App\Http\Controllers\Api\AkunController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ChatController;
use App\Http\Controllers\Api\InformasiController;
use App\Http\Controllers\Api\KonselingController;
use App\Http\Controllers\Api\NotifikasiController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\RiwayatKelasController;
use App\Http\Controllers\Api\SiswaController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes — BK System (Laravel port)
| Prefix: /api  (otomatis dari bootstrap)
| Kompatibel dengan frontend React yang memakai Authorization: Bearer <token>
|--------------------------------------------------------------------------
*/

Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout']);
Route::post('/logout-public', [AuthController::class, 'logout']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/me', [AuthController::class, 'me']);

    // Siswa
    Route::get('/siswa', [SiswaController::class, 'list']);
    Route::post('/siswa', [SiswaController::class, 'create']);
    Route::post('/siswa/import-rows', [SiswaController::class, 'importRows']);

    // Profil
    Route::get('/profile/{nis}', [ProfileController::class, 'get']);
    Route::put('/profile/{nis}', [ProfileController::class, 'update']);
    Route::put('/profile/{nis}/foto', [ProfileController::class, 'updateFoto']);
    Route::delete('/profile/{nis}/foto', [ProfileController::class, 'deleteFoto']);

    // Riwayat kelas
    Route::get('/riwayat-kelas/{nis}/aktif', [RiwayatKelasController::class, 'getAktif']);
    Route::get('/riwayat-kelas/{nis}', [RiwayatKelasController::class, 'list']);
    Route::post('/riwayat-kelas', [RiwayatKelasController::class, 'create']);
    Route::delete('/riwayat-kelas/{id}', [RiwayatKelasController::class, 'remove']);

    // Informasi BK
    Route::get('/informasi', [InformasiController::class, 'list']);
    Route::post('/informasi', [InformasiController::class, 'create']);
    Route::put('/informasi/{id}', [InformasiController::class, 'update']);
    Route::delete('/informasi/{id}', [InformasiController::class, 'remove']);

    // Konseling
    Route::get('/konseling-all', [KonselingController::class, 'listAll']);
    Route::get('/konseling-bk', [KonselingController::class, 'listByGuru']);
    Route::get('/konseling/detail/{id}', [KonselingController::class, 'getDetail']);
    Route::get('/konseling/{nis}', [KonselingController::class, 'listBySiswa']);
    Route::post('/konseling', [KonselingController::class, 'store']);
    Route::post('/konseling/walkin', [KonselingController::class, 'walkin']);
    Route::put('/konseling/{id}/konfirmasi', [KonselingController::class, 'konfirmasi']);
    Route::put('/konseling/{id}/laporan', [KonselingController::class, 'laporan']);
    Route::put('/konseling/{id}/status', [KonselingController::class, 'updateStatus']);

    // Notifikasi
    Route::get('/notifikasi', [NotifikasiController::class, 'list']);
    Route::put('/notifikasi/{id}/read', [NotifikasiController::class, 'markRead']);
    Route::put('/notifikasi/read-all', [NotifikasiController::class, 'markAllRead']);
    Route::post('/push/subscribe', [NotifikasiController::class, 'subscribe']);

    // Chat (HTTP history + AI; real-time tetap bisa pakai Socket.IO Node terpisah)
    Route::get('/chat/history', [ChatController::class, 'history']);
    Route::post('/chat/send', [ChatController::class, 'send']);
    Route::post('/chat', [ChatController::class, 'ai']); // kompatibel React: POST /api/chat
    Route::post('/chat/ai', [ChatController::class, 'ai']);

    // Akun (admin)
    Route::get('/akun/guru', [AkunController::class, 'listGuru']);
    Route::post('/akun/guru', [AkunController::class, 'createGuru']);
    Route::put('/akun/guru/{id}', [AkunController::class, 'updateGuru']);
    Route::delete('/akun/guru/{id}', [AkunController::class, 'deleteGuru']);
    Route::get('/akun/kepsek', [AkunController::class, 'listKepsek']);
    Route::post('/akun/kepsek', [AkunController::class, 'createKepsek']);
    Route::put('/akun/kepsek/{id}', [AkunController::class, 'updateKepsek']);
    Route::delete('/akun/kepsek/{id}', [AkunController::class, 'deleteKepsek']);
});
