@extends('layouts.app')
@section('title', 'Riwayat Konseling')
@section('main_class', '')
@push('styles')
<link rel="stylesheet" href="{{ asset('css/history.css') }}">
<link rel="stylesheet" href="{{ asset('css/siswa-history-shell.css') }}">
<style>
/* Cegah style link global merusak kartu */
.history-page a.history-card,
.history-page a.history-card:visited,
.history-page a.history-card:hover,
.history-page a.history-card:active {
  text-decoration: none !important;
  color: inherit !important;
}
.history-page a.history-card * {
  text-decoration: none !important;
}
.history-page .info-line-val,
.history-page .info-line-key,
.history-page .history-category,
.history-page .history-date-chip {
  color: inherit;
}
.history-page .info-line-val { color: var(--text-primary, #1a1a18); font-weight: 600; }
.history-page .info-line-key { color: var(--text-muted, #5F5E5A); }
</style>
@endpush

@section('content')
@php
    $total = $rows->count();
    $selesai = $rows->where('status', 'Selesai')->count();
    $proses = $rows->where('status', 'Proses')->count();
    $kategoriIcon = [
        'Akademik' => '📚', 'Sosial' => '👥', 'Pribadi' => '💭',
        'Karir' => '🎯', 'Bullying' => '🛡️', 'Keluarga' => '🏠',
    ];
@endphp
<div class="history-page">
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <div class="logo-icon">🛡️</div>
                <h2>StopBully</h2>
            </div>
            <p>Student Portal</p>
        </div>
        <div class="sidebar-divider"></div>
        <p class="sidebar-section-label">Menu</p>
        <ul class="sidebar-menu">
            <li>
                <a href="{{ route('siswa.profil') }}">
                    <span class="menu-icon">👤</span><span>Profile</span>
                </a>
            </li>
            <li>
                <a href="{{ route('siswa.konseling.index') }}" class="active">
                    <span class="menu-icon">📋</span><span>History</span>
                </a>
            </li>
            <li>
                <form action="{{ route('logout') }}" method="POST" style="margin:0">
                    @csrf
                    <a href="#" onclick="event.preventDefault(); if(confirm('Logout?')) this.closest('form').submit();" style="cursor:pointer">
                        <span class="menu-icon">🚪</span><span>Logout</span>
                    </a>
                </form>
            </li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="page-header">
            <div>
                <div class="breadcrumb">
                    <a href="{{ route('siswa.dashboard') }}">Home</a>
                    <span>/</span> History
                </div>
                <h1>Riwayat Konseling</h1>
                <p class="page-subtitle">
                    Status konseling akan diperbarui oleh Guru BK setelah konseling selesai dilaksanakan.
                </p>
            </div>
        </div>

        @if($total > 0)
        <div class="summary-strip">
            <div class="summary-chip">
                <div class="summary-chip-dot" style="background:var(--accent,#534AB7)"></div>
                <div>
                    <div class="summary-chip-count" style="color:var(--accent,#534AB7)">{{ $total }}</div>
                    <div class="summary-chip-label">Total Sesi</div>
                </div>
            </div>
            <div class="summary-chip">
                <div class="summary-chip-dot" style="background:var(--success,#1A7A4A)"></div>
                <div>
                    <div class="summary-chip-count" style="color:var(--success,#1A7A4A)">{{ $selesai }}</div>
                    <div class="summary-chip-label">Selesai</div>
                </div>
            </div>
            <div class="summary-chip">
                <div class="summary-chip-dot" style="background:var(--warning,#C47A00)"></div>
                <div>
                    <div class="summary-chip-count" style="color:var(--warning,#C47A00)">{{ $proses }}</div>
                    <div class="summary-chip-label">Dalam Proses</div>
                </div>
            </div>
        </div>
        @endif

        @if($total === 0)
            <div class="empty-state">
                <div class="empty-icon">📋</div>
                <div class="empty-title">Belum Ada Riwayat Konseling</div>
                <div class="empty-sub">Mulai konseling pertama Anda untuk melihat riwayat di sini</div>
            </div>
        @else
            <div class="history-grid">
                @foreach($rows as $item)
                    @php
                        $hasLaporan = !empty($item->laporan_kesimpulan) || !empty($item->laporan);
                        $isTerkonfirmasi = in_array($item->status_konfirmasi ?? '', ['Terkonfirmasi', 'Tervalidasi', 'Dikonfirmasi'], true);
                        $st = $item->status ?? 'Proses';
                        $badgeCls = $st === 'Selesai' ? 'badge-selesai' : ($st === 'Dibatalkan' ? 'badge-dibatalkan' : 'badge-proses');
                        $kat = $item->kategori ?: '—';
                        $icon = $kategoriIcon[$kat] ?? '📚';
                        $tgl = $item->tanggal ? \Carbon\Carbon::parse($item->tanggal)->translatedFormat('d M Y') : '—';
                        $jam = $item->jam ? substr((string) $item->jam, 0, 5) : '—';
                        $warningNote = $st === 'Selesai' && !$hasLaporan;
                    @endphp
                    <a href="{{ route('siswa.konseling.show', $item->id) }}" class="history-card">
                        <div class="history-card-header">
                            <div class="history-category">
                                <div class="category-icon">{{ $icon }}</div>
                                Konseling {{ $kat }}
                            </div>
                            <div class="history-date-chip">📅 {{ $tgl }}</div>
                        </div>

                        <div class="history-card-body">
                            <div class="info-line">
                                <div class="info-line-icon">👨‍🏫</div>
                                <div class="info-line-key">Guru BK</div>
                                <div class="info-line-val">{{ $item->guru_bk ?: '—' }}</div>
                            </div>
                            <div class="info-line">
                                <div class="info-line-icon">📖</div>
                                <div class="info-line-key">Jenis</div>
                                <div class="info-line-val">{{ $item->jenis ?: '—' }}</div>
                            </div>
                            <div class="info-line">
                                <div class="info-line-icon">🕐</div>
                                <div class="info-line-key">Jam</div>
                                <div class="info-line-val">{{ $jam }}</div>
                            </div>
                            <div class="info-line">
                                <div class="info-line-icon">📌</div>
                                <div class="info-line-key">Status</div>
                                <div class="info-line-val">
                                    <span class="badge {{ $badgeCls }}">
                                        <span class="badge-dot"></span>{{ $st }}
                                    </span>
                                </div>
                            </div>
                            @if($st === 'Proses')
                            <div class="info-line">
                                <div class="info-line-icon">{{ $isTerkonfirmasi ? '✅' : '⏳' }}</div>
                                <div class="info-line-key">Konfirmasi</div>
                                <div class="info-line-val">
                                    @if($isTerkonfirmasi)
                                        Sudah dikonfirmasi
                                    @else
                                        Menunggu konfirmasi jadwal
                                    @endif
                                </div>
                            </div>
                            @endif
                        </div>

                        @if($warningNote)
                            <div class="history-warning">⚠️ Sesi selesai, laporan belum diisi Guru BK</div>
                        @endif

                        <div class="history-card-footer">
                            <div class="history-badges">
                                @if($hasLaporan)
                                    <span class="badge badge-laporan"><span class="badge-dot"></span> Ada Laporan</span>
                                @elseif($st === 'Selesai')
                                    <span class="badge badge-nolap"><span class="badge-dot"></span> Tanpa Laporan</span>
                                @endif
                            </div>
                            <span class="card-arrow">Lihat detail →</span>
                        </div>
                    </a>
                @endforeach
            </div>
        @endif
    </main>
</div>
@endsection
